package exercice01_serie4;
import java.lang.ArrayIndexOutOfBoundsException;
public class Pile {
	

	private final static int taille = 10; 
	private Object  pile []; 
	private int pos;
	
	Pile() { pile=new Object[taille]; pos=0; }
	public void pile(Object o) throws Exception{
	try {
	pile[pos]=o;
	pos++;
	}
	catch(ArrayIndexOutOfBoundsException e){
	throw new Exception("Pile pleine!");
	}
	}
	public Object pile() throws PileVide{
	try {
	Object o = pile[pos-1];
	pos--;
	return o;
	}
	catch(ArrayIndexOutOfBoundsException e){
	throw new PileVide("Pile vide!");}
	
 
	public  Pile(int pos)throws PilePliene {
		
	}


	public void setPile(Object [] pile) {
		this.pile = pile;
	}


	public Object [] getPile() {
		return pile;
	}


	public void setPos(int pos) {
		this.pos = pos;
	}


	public int getPos() {
		return pos;
	}


	public static int getTaille() {
		return taille;
	}

}
