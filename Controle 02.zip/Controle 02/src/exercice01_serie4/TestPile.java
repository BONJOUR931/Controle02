package exercice01_serie4;

public class TestPile {

	
	public static void main(String[] args) throws Exception {
		Pile P = new Pile();
		
		for(int i=0;i<args.length;i++){
			try {
				
				P.pile(args[i]);
			} catch (PilePliene e) {
				 System.out.println();
				e.printStackTrace();
			}try {System.out.println(P.pile()+" ");
				}catch(PileVide e1) { System.out.println(); 
			}
		}
		
	}		
		
}

