package exercice01_serie4;
import java.lang.ArrayIndexOutOfBoundsException;
public class PileVide extends Exception{

	public PileVide(String s) {
		
			super (s);
			
		}
	

}
