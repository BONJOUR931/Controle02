package exercice01_serie4;
import java.lang.ArrayIndexOutOfBoundsException;
public class PilePliene extends Exception{

		public PilePliene(String s) {
			super (s);
			
		}


}
