package exercice06_serie2;
import java.util.Date;
public class Cadre extends Employe {
private int indice;
     
public Cadre(String matricule, String nom, String prenom, Date DateNaiss,int i) {
	super(matricule,nom,prenom,DateNaiss);
	this.indice=i;
	}

	public double getSalaire() {
		if (indice == 1)
            return 12000;
        else if (indice == 2)
            return 14000;
        else if (indice == 3)
            return 16000;
        else if (indice == 4)
            return 18000;
        else
            return -1;
	
	}

	public void setIndice(int indice) {
		this.indice = indice;
	}

	public int getIndice() {
		return indice;
	}
	 public String toString() {
	        return "Cadre[" + "indice=" + getIndice() + ']';
	    }
	    

}
