package exercice06_serie2;
import java.util.Date;
public class Associe extends Employe{
 private double BN;
 private double x;
 private double CA;
	public Associe() {
	}

public Associe(double CA, double benefice, double pourcentage, String matricule, String nom, String prenom, Date datenaiss) {
    super(matricule, nom, prenom, datenaiss);
    this.CA = CA;
    this.BN = benefice;
    this.x = pourcentage;
}


public String toString() {
    return "Associe{" + "CA=" + CA + ", benefice=" + BN + ", pourcentage=" + x + '}';
}
    
    
    

public double getSalaire() {
    double salaire;
    salaire=BN*x/100;
    return salaire;
    
    
}


}
