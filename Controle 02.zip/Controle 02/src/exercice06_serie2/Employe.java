package exercice06_serie2;
import java.util.Date;

public abstract class Employe {
	private String matricule;
	private String nom;
	private String prenom;
	private Date datedenaissance;
	
	public Employe(String matricule,String nom,String prenom,Date dn) {
		
	}
    public Employe() {
		
	}
     
    
    public abstract double getSalaire();
   
    
    public String getMatricule() {
		return matricule;
	}
	public void setMatricule(String matricule) {
		this.matricule = matricule;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public Date getDatedenaissance() {
		return datedenaissance;
	}
	public void setDatedenaissance(Date datedenaissance) {
		this.datedenaissance = datedenaissance;
	}
	
	public String toString()

    {
		return "matricule : "+ matricule + " Nom :" + nom.toUpperCase()+" Prenom :" + prenom.toLowerCase() + "Date de naissance :" + datedenaissance;
		
    }
	
}