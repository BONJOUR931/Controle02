package exercice06_serie2;
import java.util.Date;
public class Employe_test {

	public static void main(String[] args) {
		 Ouvrier o= new Ouvrier("12443","HIBA","HIba",new Date(2001),new Date(2010),2000);
	     System.out.println(o);
	     System.out.println(o.getSalaire());
	     
	     Cadre c=new Cadre("TD123","Farih","Hajar",new Date(2001),5);
	     System.out.println(c);
	     System.out.println(c.getSalaire());
	     
	     Associe a=new Associe(3000,6754,43, "jj59788","hfghfg","hgjf",new Date(2001));
	     System.out.println(a);
	     System.out.println(a.getSalaire());
	}

}
