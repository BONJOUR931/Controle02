package exercice06_serie2;

import java.util.Date;

public class Ouvrier extends Employe{
	double salaire;
	private Date dateEntree ;
	private static int SMIG=3000;
	

	public Ouvrier( String mat, String nom, String prenom, Date dn, Date dateEntree,double salaire) {
		super(mat,nom,prenom,dn);
		this.salaire=salaire;
		this.dateEntree = dateEntree;
		
	}
	public Ouvrier(double salaire, Date dE) {
        this.salaire = salaire;
        this.dateEntree = dE;
        
    }

	
	public double getSalaire() {
		 int anciennete;
	        double SMIG=3000;
	        Date aujourhui=new Date();
	        anciennete= aujourhui.getYear()+1900- dateEntree.getYear();
	        
	        salaire= SMIG+anciennete*(100);
	        if (salaire>=SMIG*2)
	        { System.out.println("reffuser! salaire d�passer SMIG*2");}
	        else
	        { System.out.println(" Salaire :"+salaire); }
	        
	            
	                    return salaire;
	    }
	
	

	public Date getDateEntree() {
		return dateEntree;
	}


	public static int getSMIG() {
		return SMIG;
	}




	public void setDateEntree(Date dateEntree) {
		this.dateEntree = dateEntree;
	}
	public String toString(){
		return "Ouvrier : " + super.toString()+ "Sa date d'entr�e : "+ dateEntree.getYear()+ "son Salaire :" + salaire;
		
	}

}
