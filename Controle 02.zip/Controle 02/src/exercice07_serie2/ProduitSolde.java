package exercice07_serie2;

public interface ProduitSolde {
	public void LancerSolde(double pourcentage);
	public void terminerSolde(double pourcentage);

}
