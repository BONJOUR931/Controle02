package exercice07_serie2;
import java.util.Date;
public interface ProduitPrime {
public Date datePer();
public int joursRest();
}
