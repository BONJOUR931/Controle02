package exercice07_serie2;
import java.util.Date;
public class Primeurs extends Article{
	Date datePremeption;

	public Primeurs() {
		
	}
	public Primeurs(double prixAcht,double prixVnt,String nom,String fornis,Date datePremeption){
	super();
	PrixAchat=prixAcht;
	PrixVente=prixVnt;
	this.nom=nom;
	this.fornis=fornis;
	this.datePremeption=datePremeption;
	}
	public String toString(){
		return super.toString()+"Premeurs : date de premeption "+datePremeption;
	}

}
