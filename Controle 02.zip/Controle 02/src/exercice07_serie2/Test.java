package exercice07_serie2;

public class Test {

	
	public static void main(String[] args) {
		Article A=new Article();
		Electromanager E=new Electromanager();

	}

}
