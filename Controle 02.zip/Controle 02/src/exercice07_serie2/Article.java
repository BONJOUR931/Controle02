package exercice07_serie2;

public class Article {
	double PrixAchat;
	double PrixVente;
	String nom;
	String fornis;

	public Article(String nom,String fornis) {
		super();
		this.nom=nom;
		this.fornis=fornis;
		
	}
	public Article() {
		
	}
	public Article(double prixAchat2, double prixVente2, String nom2,
			String fornisseur) {
	}
	public double CalculterDeTaux(){
		return 0;
	}
	public String toString()
	{
		return "Prix d'achat de l'article : "+PrixAchat+",Prix de vente : "+PrixVente+",Nom : "+nom+"Fornisseur : "+fornis;
	}

}
