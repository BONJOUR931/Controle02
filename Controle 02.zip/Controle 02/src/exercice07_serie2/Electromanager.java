package exercice07_serie2;

public class Electromanager extends Article implements ProduitSolde {
	double volt;
	String marque;
	

	public Electromanager(double voltage,String marque) {
		super();
		this.volt=voltage;
		this.marque=marque;
		
	}
	public Electromanager(double prixAchat,double prixVente,String nom,String fornisseur, double volt, String marque){
	super(prixAchat,prixVente,nom,fornisseur);
	this.volt=volt;
	this.marque=marque;
	}
	public Electromanager() {
		
	}
	public String toString(){
		return super.toString()+"Electromanager :[ Voltage = "+volt+"Marque = "+marque+"]";
	}


	public void LancerSolde(double pourcentage) {
		
		
	}


	public void terminerSolde(double pourcentage) {
		
		
	}

}
