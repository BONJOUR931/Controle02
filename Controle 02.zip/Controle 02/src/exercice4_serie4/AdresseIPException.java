package exercice4_serie4;
import java.lang.Exception;
public class AdresseIPException extends Exception  {

	public AdresseIPException(String P) {
		
		super(P);
		
	}

}
