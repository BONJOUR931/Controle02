package exercice4_serie4;
import java.lang.Exception;
public class TestAdresseIP {

	
	public static void main(String[] args) throws AdresseIPException {
		 AdresseIP adr= new AdresseIP(323, 156, 111, 147);
		 try {
	            AdresseIP adrs = new AdresseIP(/* 123 ou */323, 156, 111, 147);
	        } catch (AdresseIPException ex) {
	          System.out.println("Erreur Construction");
	          System.out.println(ex.getMessage());
	          //ex.printStackTrace();
	          System.exit(-1);
	        }
	}

}
