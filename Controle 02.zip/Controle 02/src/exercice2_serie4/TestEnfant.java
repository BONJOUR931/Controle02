package exercice2_serie4;
public class TestEnfant {

	
	public static void main(String[] args) throws AgeEnfantException {
		Enfant E1=new Enfant();
		System.out.println(E1);
try {
	E1.setAge(12);
	
}catch(AgeEnfantException a){
	System.out.println(a.toString());

}

	}

}
