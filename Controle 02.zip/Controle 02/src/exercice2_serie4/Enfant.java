package exercice2_serie4;

public class Enfant {
	private int age;
	public Enfant(int age) throws AgeEnfantException{
		this.age=getAge();
	}
	public Enfant() {
		
	}
	public int getAge() {
		return age;
	}

	public void setAge(int age) throws AgeEnfantException {
		if (age>=1 && age<10){
			this.age=age;
		}else{
			throw new AgeEnfantException();
		}
		
	}

}
