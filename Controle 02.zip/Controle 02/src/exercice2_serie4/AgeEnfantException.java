package exercice2_serie4;
public class AgeEnfantException extends Exception {

		public AgeEnfantException(){super ();}
		
		public String toString() {
			return "l'ans n'est pas valide !";
			
		}

	
}