package exercice03_serie4;
import java.lang.ArrayIndexOutOfBoundsException;
public class TestVile {

	
	public static void main(String[] args) throws PopulationException{
		 try{
			 Ville v = new Ville("Rabat", -23524, "Maroc");
		 }catch(PopulationException p){
		  
		  System.out.println(p.getMessage());
		
		 }
	}

}
