package exercice03_serie4;
//import java.lang.Exception;
public class PopulationException extends Exception {
	public PopulationException() 
{
	super();
}
public String getMessage()
{
	return " impossible !!! le nombre de population est n�gatif !";
}  

}
