package exercice03_serie4;
import java.lang.Exception;
public class Ville extends PopulationException {
	private String nom;
	private int population;
	private String pays;


	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public int getPopulation() {
		return population;
	}


	public void setPopulation(int population) throws PopulationException{
		if(population>=0) 
		{
			this.population=population;
		}
			
		else{
			throw new PopulationException();
		}
	}


	public String getPays() {
		return pays;
	}


	public void setPays(String pays) {
		this.pays = pays;
	}
	public Ville() {}
	public Ville(String n,int popul,String p )
	{
		this.nom=n;
		this.pays=p;
		setPopulation(popul);
	}
	  public String toString()
	  {
		  return getNom()+" ville de  "+getPopulation()+ " habitants se situant en " + getPays();
	  }

}
